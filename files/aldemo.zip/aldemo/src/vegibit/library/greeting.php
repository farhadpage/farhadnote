<?php
namespace VegibitLibrary;
 
Class Greeting
{
    public function hi()
    {
        return "We got you covered";
    }
}
