<?php
 
require 'vendor/autoload.php';
 
echo lego();
 
$cm = new Cmautoload;
echo $cm->classmap();
 
$obj = new VegibitLibrary\Greeting();

echo $obj->hi();
