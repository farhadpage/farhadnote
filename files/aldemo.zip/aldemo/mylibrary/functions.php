<?php

function lego () {
    return 'You are now a master builder.';
}