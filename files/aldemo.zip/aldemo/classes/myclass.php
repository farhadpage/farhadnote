<?php
Class Cmautoload {
 
	  public function classmap () {
		  return 'that knows how to autoload with a classmap! ';
	  }
}